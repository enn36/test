# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me at max@a42.ch

import tentacles.Meta.Keywords.matrix_library.pro_tentacles.pro_modes.strategy_maker.abstract_strategy_maker_trading_mode as abstract_strategy_maker_trading_mode
import octobot_commons.logging as logging


class StrategyMakerMode(abstract_strategy_maker_trading_mode.AbstractStrategyMakerMode):
    def __init__(self, config, exchange_manager):
        super().__init__(config, exchange_manager)
        self.producer = StrategyMakerModeProducer
        if exchange_manager:
            try:
                import backtesting_script

                self.register_script_module(backtesting_script, live=False)
            except (AttributeError, ModuleNotFoundError):
                pass
            try:
                import profile_trading_script

                self.register_script_module(profile_trading_script)
            except (AttributeError, ModuleNotFoundError):
                pass
        else:
            logging.get_logger(self.get_name()).error(
                "At least one exchange must be enabled to use StrategyMakerMode"
            )


class StrategyMakerModeProducer(abstract_strategy_maker_trading_mode.StrategyMaker):
    pass
